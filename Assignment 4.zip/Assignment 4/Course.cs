﻿using System.Collections.Generic;


public class Course
{
    
    public int CourseID { get; set; }
    public string Code { get; set; }
    public string Name { get; set; }
    public List<Student> Students { get; set; }

    
    public Course(int courseId, string code, string name)
    {
        CourseID = courseId;
        Code = code;
        Name = name;
        Students = new List<Student>();
    }
}
