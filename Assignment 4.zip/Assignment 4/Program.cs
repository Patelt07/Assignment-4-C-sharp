﻿using System;

class Program
{
    static void Main()
    {
       
        var course1 = new Course(1, "CMSK154", "C# Fundamentals");
        var course2 = new Course(2, "CMSK152", "JavaScript Fundamentals");

       
        var student1 = new Student(1, "John", "Jones");
        var student2 = new Student(2, "Karen", "Knight");
        var student3 = new Student(3, "Susan", "Steavens");
        var student4 = new Student(4, "Allan", "Anderson");
        var student5 = new Student(5, "Gerry", "Garvis");

        
        course1.Students.Add(student1);
        course1.Students.Add(student2);
        course1.Students.Add(student3);

        course2.Students.Add(student4);
        course2.Students.Add(student5);

       
        Console.WriteLine("Course List");
        Console.WriteLine("-----------");

        foreach (var course in new Course[] { course1, course2 })
        {
            Console.WriteLine($"{course.CourseID}  {course.Code}  {course.Name}");

            foreach (var student in course.Students)
            {
                Console.WriteLine($"            {student.StudentID} {student.FirstName} {student.LastName}");
            }

            Console.WriteLine(); 
        }
    }
}
