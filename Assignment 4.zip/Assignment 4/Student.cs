﻿public class Student
{
   
    public int StudentID { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }

    public Student(int studentId, string firstName, string lastName)
    {
        StudentID = studentId;
        FirstName = firstName;
        LastName = lastName;
    }
}
